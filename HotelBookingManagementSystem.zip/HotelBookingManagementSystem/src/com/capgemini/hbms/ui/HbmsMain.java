package com.capgemini.hbms.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hbms.bean.BookingBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserBean;

import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserServiceImpl;

public class HbmsMain {

	private String password;
	private String userName;
	private String mobileNo;
	private String phone;
	private String address;
	private String email;
	
	private String bookingId;
	private int noOfAdults;
	private int noOfChildren;
	private double amount;
	
	private String hotelId;
	private String hotelName;
	private String city;
	private String description;
	private Double avgRatePerNight;
	private String phoneNo1;
	private String phoneNo2;
	private String rating;
	private String fax;

	private String roomId;
	private String roomNo;
	private Double perNightRate;
	private String roomType;
	private String availability;
	private String photo;

	
	
	static Scanner scInput = new Scanner(System.in);
	
	
	UserBean userBean=new UserBean();
	HotelBean hotelBean = new HotelBean();
	BookingBean bookingBean = new BookingBean();
	RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
	
	
	IUserService userService = new UserServiceImpl();
	IHotelService hotelService=new HotelServiceImpl();
	IRoomService roomService=new RoomServiceImpl();
	IBookingService bookingService = new BookingServiceImpl();


	public static void main(String[] args) {
	
		String choice;

		while (true) {

			System.out.println("\n*************************\nHOTEL MANAGEMENT SYSTEM\n*************************");
			System.out.println("\n\n\n1.Admin\n2.Employee\n3.Customer\n\n");

			choice = scInput.nextLine();
			
			switch (choice) {

			case "1":
				
				Admin admin = new Admin();
				admin.main();
				break;
			
			case "2":
			
				
				HotelEmployee employee = new HotelEmployee();
				employee.main();
				break;
			
			case "3":
				
				
				Customer customer = new Customer();
				customer.customerMain();
				break;
			

			default:
				System.err.println("Entered choice is incorrect. Please select a valid number!!\n\n");
				break;

			}

		}

	}

	public UserBean Register(String role) {

			System.out.print("Enter UserName : ");
			userName = scInput.nextLine();
			System.out.print("Enter Password : ");
			password = scInput.nextLine();
			System.out.print("Enter Mobile Number : ");
			mobileNo = scInput.nextLine();
			System.out.print("Enter Phone Number : ");
			phone = scInput.nextLine();
			System.out.print("Enter Address : ");
			address = scInput.nextLine();
			System.out.print("Enter Email : ");
			email = scInput.nextLine();

			userBean = new UserBean(userName, password, role, mobileNo, phone, address, email);
			return userBean;
		}
	

public List<String> viewCities() {

	List<HotelBean> listOfHotels;
	List<String> repeatedCities = new ArrayList<String>();
	List<String> cities = new ArrayList<String>();
	int flag = 1;
	try {
		listOfHotels = hotelService.viewHotelsList();

		for (HotelBean hotel : listOfHotels) {
			repeatedCities.add(hotel.getCity());
		}

		for (String city : repeatedCities) {

			if (cities.isEmpty()) {
				cities.add(city);
			} else {

				for (String cityCheck : cities) {

					if (city.matches(cityCheck)) {
						flag = 0;
					}
				}
				if (flag == 1) {
					cities.add(city);
				}
				flag = 1;
			}
		}
	} catch (HbmsException e) {
		System.out.println("Cities couldnt be retrived");
		e.printStackTrace();
	}

	return cities;
}

public int HotelSearch(String city) {
	
	int index = 0;
	try {
		List<HotelBean> hotelsList = hotelService.viewHotels(city);

		if (hotelsList.isEmpty()) {
			;
		} else {

			System.out.println("\n\nHotels List\n");

			System.out.println(
					"Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

			for (HotelBean hotel : hotelsList) {

				++index;
				System.out.println(hotel.getHotelId() + "           " + hotel.getCity() + "     "
						+ hotel.getHotelname() + "      " + hotel.getAddress() + "      " + hotel.getDescription()
						+ "              " + hotel.getAvgRatePerNight() + "             " + hotel.getPhoneNo1()
						+ "      " + hotel.getPhoneNo2() + "      " + hotel.getRating() + "      "
						+ hotel.getEmail() + "      " + hotel.getFax());
			}

			System.out.println("\nTotal Hotels found : " + index + "\n\n");
		}
	} catch (HbmsException e) {
		System.out.println("\nDue to some reason Hotel lists are not available");
		e.printStackTrace();
	}
	return index;
	
}

public boolean viewHotelRooms(String hotelId, String city, String role) {
	
	
	boolean found = false;
	boolean check = false;
	try {

		HotelBean hotelDetailsBean = hotelService.viewHotel(hotelId);

		if (hotelDetailsBean == null) {
			;
		} else {

			if (city.equals("$no$city$")) {
				check = true;
			} else {
				check = hotelDetailsBean.getCity().equalsIgnoreCase(city);
			}
			if (check) {

				List<RoomDetailsBean> roomDetails = roomService.viewRooms(hotelId);

				if (role.equals("Admin")) {
					found = true;
				} else {
					if (roomDetails.isEmpty()) {

						System.out.println("\nNo rooms are there in specified Hotel\n");

					} else {
						System.out.println("\n\nRoom details for Hotel ID : " + hotelId);

						System.out.println(
								"Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");
						for (RoomDetailsBean roomDetail : roomDetails) {

							if (roomDetail.getRoomType().equals("AC")) {
								System.out.println(roomDetail.getHotelId() + "             "
										+ roomDetail.getRoomId() + "            " + roomDetail.getRoomNo()
										+ "             " + roomDetail.getRoomType() + "               "
										+ roomDetail.getPerNightRate() + "             "
										+ roomDetail.getAvailability());
							} else {
								System.out.println(roomDetail.getHotelId() + "             "
										+ roomDetail.getRoomId() + "            " + roomDetail.getRoomNo()
										+ "             " + roomDetail.getRoomType() + "           "
										+ roomDetail.getPerNightRate() + "             "
										+ roomDetail.getAvailability());
							}

						}
						found = true;
					}
				}
			}
		}

	} catch (HbmsException e) {
		System.out.println("No rooms available");
		e.printStackTrace();
	}
	return found;
}

public String Book(String roomID, String userId) {
	
	System.out.println("\n-----------------------\nEnter Booking Details\n-----------------------\n\n");
	System.out.print("From Date (dd/MM/yyyy)    : ");
	String bookF = scInput.nextLine();

	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	TemporalAccessor ta1 = dtf.parse(bookF);
	LocalDate bookFrom = LocalDate.from(ta1);

	System.out.print("To Date (dd/MM/yyyy)      : ");
	String bookT = scInput.nextLine();

	TemporalAccessor ta2 = dtf.parse(bookT);
	LocalDate bookTo = LocalDate.from(ta2);

	System.out.print("Enter the no. of adults   : ");
	noOfAdults = scInput.nextInt();
	scInput.nextLine();

	System.out.print("Enter the no. of children : ");
	noOfChildren = scInput.nextInt();
	scInput.nextLine();

	long daysBetween = ChronoUnit.DAYS.between(bookFrom, bookTo);

	String ratePerNight;
	try{
		ratePerNight = roomService.getRoomRate(roomID);
	
	int rate = Integer.parseInt(ratePerNight);

	amount = daysBetween * rate;

	bookingBean.setUserId(userId);
	bookingBean.setRoomId(roomID);
	bookingBean.setBookedFrom(bookFrom);
	bookingBean.setBookedTo(bookTo);
	bookingBean.setNoOfAdults(noOfAdults);
	bookingBean.setNoOfChildren(noOfChildren);
	bookingBean.setAmount(amount);

	bookingId = bookingService.bookHotelRoom(bookingBean);

	System.out.println("\n\nHotel Booked Successfully!!!!\n\nYour Booking Id is " + bookingId + "\n");
	
	}
	catch(HbmsException e)
	{
		System.out.println("Booking failed");
	}
	return bookingId;
}

public boolean addHotel() throws HbmsException {
	
	boolean isInserted = false;

	System.out.println("\n\n-----------------\nADD HOTEL\n-----------------\n\n");
	System.out.print("Enter Hotel Name                   : ");
	hotelName = scInput.nextLine();
	System.out.print("Enter Hotel City                   : ");
	city = scInput.nextLine();
	System.out.print("Enter Hotel Address                : ");
	address = scInput.nextLine();
	System.out.print("Enter Hotel Description            : ");
	description = scInput.nextLine();
	System.out.print("Enter Hotel Average Rate Per Night : ");
	avgRatePerNight = scInput.nextDouble();
	scInput.nextLine();
	System.out.print("Enter Hotel Rating                 : ");
	rating = scInput.nextLine();
	System.out.print("Enter Hotel Phone Number (1)       : ");
	phoneNo1 = scInput.nextLine();
	System.out.print("Enter Hotel Phone Number (2)       : ");
	phoneNo2 = scInput.nextLine();
	System.out.print("Enter Hotel Email ID               : ");
	email = scInput.nextLine();
	System.out.print("Enter Hotel Fax number             : ");
	fax = scInput.nextLine();

	HotelBean hotelDetailsBean = new HotelBean(city, hotelName, address, description, avgRatePerNight,
			phoneNo1, phoneNo2, rating, email, fax);

	try {
		
	
		int hotelId = hotelService.insertHotel(hotelDetailsBean);

		isInserted = true;
		System.out.println("\nYou have successfully added a new Hotel!!!\n\n");

		System.out.println("Hotel Details\n");
		System.out.println("Hotel ID               : " + hotelId);
		System.out.println("Hotel Name             : " + hotelDetailsBean.getHotelname());
		System.out.println("City                   : " + hotelDetailsBean.getCity());
		System.out.println("Address                : " + hotelDetailsBean.getAddress());
		System.out.println("Description            : " + hotelDetailsBean.getDescription());
		System.out.println("Average Rate Per Night : " + hotelDetailsBean.getAvgRatePerNight());
		System.out.println("Rating                 : " + hotelDetailsBean.getRating());
		System.out.println("Phone Number (1)       : " + hotelDetailsBean.getPhoneNo1());
		System.out.println("Phone Number (2)       : " + hotelDetailsBean.getPhoneNo2());
		System.out.println("Email ID               : " + hotelDetailsBean.getEmail());
		System.out.println("Fax number             : " + hotelDetailsBean.getFax());

	} catch (HbmsException e) {
		throw new HbmsException("Sorry !! Hotel couldn't be added \n" + e.getMessage());
	}

	return isInserted;
	
}

public boolean deleteHotel(String role) throws HbmsException  {
	
	
	boolean isDeleted = false;
	boolean choiceCity = false;
	boolean hotelDeleted = false;
	boolean choiceHotelId = false;
	IHotelService hotelService = new HotelServiceImpl();
	List<HotelBean> listOfHotels = new ArrayList<HotelBean>();

	System.out.println("\n\n-----------------\nDELETE HOTEL\n-----------------\n\n");
	System.out.println("1. Search hotel by City to delete hotel");
	System.out.println("2. Delete Hotel by Hotel Id");
	System.out.println("3. Cancel\n\n");

	System.out.print("Enter the choice : ");
	String choice = scInput.nextLine();

	switch (choice) {

	case "1":
		List<String> cities = viewCities();

		while (!choiceCity) {

			System.out.println("\nSelect the city\n");
			for (String c : cities) {
				System.out.print(c + "          ");
			}

			System.out.print("\nEnter the city : ");
			city = scInput.nextLine();

			listOfHotels = hotelService.viewHotels(city);
			if (listOfHotels.isEmpty()) {

				System.out.println("\nPlease enter the city name properly !!\n");

			} else {
				choiceCity = true;
				System.out.println(
						"\nHotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

				for (HotelBean hotelDetailsBean : listOfHotels) {
					System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity()
							+ "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress()
							+ "      " + hotelDetailsBean.getDescription() + "              "
							+ hotelDetailsBean.getAvgRatePerNight() + "             "
							+ hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      "
							+ hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      "
							+ hotelDetailsBean.getFax());
				}

				while (!choiceHotelId) {

					System.out.print("\nEnter the hotel Id to be deleted : ");
					hotelId = scInput.nextLine();
					if (viewHotelRooms(hotelId, city, role)) {

						choiceHotelId = true;

						while (!hotelDeleted) {
							if (deleteHotelDetails(hotelId)) {
								hotelDeleted = true;
								isDeleted = true;
								System.out.println("\nHotel deleted successfully !!\n\n");

							} else {
								System.out.println("\nPlease enter a valid Hotel Id !!\n");
							}
						}

					} else {
						System.out.println("\nPlease enter a valid Hotel Id !!\n");
					}
				}
			}
		}
		break;

	case "2":
		int result = deleteHotelById();
		if (result == 1) {
			isDeleted = true;
		}
		break;

	case "3":
		isDeleted = true; // end loop in AdminMain
		break;
	default:
		System.out.println("\nPlease choose a valid option !!\n");
		break;
	}
	return isDeleted;

}

public int deleteHotelById() {
	System.out.print("\nEnter Hotel Id : ");
	hotelId = scInput.nextLine();

	int result = 0;
	boolean isDeleted = false;
	try {
		HotelBean hotelDetailsBean = hotelService.viewHotel(hotelId);

		if (hotelDetailsBean != null) {
			while (!isDeleted) {
				System.out.println("\n\n");
				System.out.println(
						"Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

				System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity()
						+ "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress()
						+ "      " + hotelDetailsBean.getDescription() + "              "
						+ hotelDetailsBean.getAvgRatePerNight() + "             " + hotelDetailsBean.getPhoneNo1()
						+ "      " + hotelDetailsBean.getPhoneNo2() + "      " + hotelDetailsBean.getRating()
						+ "      " + hotelDetailsBean.getEmail() + "      " + hotelDetailsBean.getFax());

				System.out.println("\n\n1. Delete Hotel Details");
				System.out.println("2. Cancel\n\n");
				System.out.print("Enter : ");
				String delete = scInput.nextLine();

				switch (delete) {
				case "1":

					isDeleted = deleteHotelDetails(hotelId);
					if (isDeleted) {
						result = 1;
					}

					break;

				case "2":
					System.out.println("\nDeletion Cancelled !!\n");
					result = 2;
					isDeleted = true;
					break;

				default:
					System.out.println("\nEnter a valid option\n");
					break;
				}
			}
		} else {
			System.out.println("\nHotel record with hotel id " + hotelId + " not found!!\n\n");
		}
	} catch (HbmsException e) {
		System.out.println("Hotel not found!!" + e.getMessage());
	}
	return result;
}

public boolean deleteHotelDetails(String hotelId) {

	boolean isHotelDeleted = false;
	try {
		isHotelDeleted = hotelService.deleteHotel(hotelId);
	} catch (HbmsException e) {
		System.out.println(e.getMessage());
	}

	return isHotelDeleted;
}

public boolean updateHotel(String role) throws HbmsException {
	boolean isUpdated = false;
	boolean choiceCity = false;
	boolean hotelUpdated = false;
	boolean choiceHotelId = false;
	IHotelService hotelService = new HotelServiceImpl();
	List<HotelBean> listOfHotels = new ArrayList<HotelBean>();

	System.out.println("\n\n-----------------\nMODIFY HOTEL\n-----------------\n\n");
	System.out.println("1. Search hotel by City to modify hotel details");
	System.out.println("2. Search Hotel by Hotel Id to modify details");
	System.out.println("3. Cancel\n\n");

	System.out.print("Enter the choice : ");
	String choice = scInput.nextLine();

	switch (choice) {

	case "1":
		List<String> cities = viewCities();

		while (!choiceCity) {

			System.out.println("\nSelect the city\n");
			for (String c : cities) {
				System.out.print(c + "          ");
			}

			System.out.print("\nEnter the city : ");
			city = scInput.nextLine();

			listOfHotels = hotelService.viewHotels(city);
			if (listOfHotels.isEmpty()) {

				System.out.println("\nPlease enter the city name properly !!\n");

			} else {
				choiceCity = true;
				System.out.println(
						"\nHotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

				for (HotelBean hotelDetailsBean : listOfHotels) {
					System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity()
							+ "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress()
							+ "      " + hotelDetailsBean.getDescription() + "              "
							+ hotelDetailsBean.getAvgRatePerNight() + "             "
							+ hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      "
							+ hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      "
							+ hotelDetailsBean.getFax());
				}

				while (!choiceHotelId) {

					System.out.print("\nEnter the hotel Id to be updated : ");
					hotelId = scInput.nextLine();
					if (viewHotelRooms(hotelId, city, role)) {

						choiceHotelId = true;

						while (!hotelUpdated) {
							if (updateHotelById(hotelId)) {
								hotelUpdated = true;
								isUpdated = true;
								System.out.println("\nHotel updated successfully !!\n\n");

							} else {
								System.out.println("\nPlease enter a valid Hotel Id !!\n");
							}
						}

					} else {
						System.out.println("\nPlease enter a valid Hotel Id !!\n");
					}
				}
			}
		}
		break;

	case "2":

		while (!choiceHotelId) {

			city = "$no$city$";
			System.out.print("\nEnter the hotel Id to be updated : ");
			hotelId = scInput.nextLine();
			if (viewHotelRooms(hotelId, city, role)) {

				choiceHotelId = true;

				while (!hotelUpdated) {
					if (updateHotel(hotelId)) {
						hotelUpdated = true;
						isUpdated = true;
						System.out.println("\nHotel updated successfully !!\n\n");

					} else {
						System.out.println("\nPlease enter a valid Hotel Id !!\n");
					}
				}

			} else {
				System.out.println("\nPlease enter a valid Hotel Id !!\n");
			}
		}
		break;

	case "3":
		isUpdated = true; // end loop in AdminMain
		break;
	default:
		System.out.println("\nPlease choose a valid option !!\n");
		break;
	}
	return isUpdated;
}

public boolean updateHotelById(String hotelId2) {
	
	boolean isUpdated = false;
	try {
		HotelBean hotelDetailsBean = hotelService.viewHotel(hotelId);

		if (hotelDetailsBean != null) {
			while (!isUpdated) {

				System.out.println("\n\n");
				System.out.println(
						"Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

				System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity()
						+ "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress()
						+ "      " + hotelDetailsBean.getDescription() + "              "
						+ hotelDetailsBean.getAvgRatePerNight() + "             " + hotelDetailsBean.getPhoneNo1()
						+ "      " + hotelDetailsBean.getPhoneNo2() + "      " + hotelDetailsBean.getRating()
						+ "      " + hotelDetailsBean.getEmail() + "      " + hotelDetailsBean.getFax());

				System.out.println("\n\nModify\n");
				System.out.println("1. Hotel Name");
				System.out.println("2. City");
				System.out.println("3. Address");
				System.out.println("4. Description");
				System.out.println("5. Average Rate Per Night");
				System.out.println("6. PhoneNo 1");
				System.out.println("7. PhoneNo 2");
				System.out.println("8. Rating");
				System.out.println("9. Email");
				System.out.println("10. Fax");
				System.out.println("\n11. Modify All Data\n\n");
				System.out.print("Enter : ");
				String update = scInput.nextLine();

				switch (update) {
				case "1":
					System.out
							.println("\n\n------------------------------------------\nModify Hotel Name of hotel '"
									+ hotelDetailsBean.getHotelname()
									+ "'\n------------------------------------------\n\n");
					System.out.print("Enter new Hotel Name : ");
					hotelName = scInput.nextLine();

					hotelDetailsBean.setHotelname(hotelName);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "2":

					System.out.println("\n\n------------------------------------------\nModify City of hotel '"
							+ hotelDetailsBean.getHotelname()
							+ "'\n------------------------------------------\n\n");
					System.out.print("Enter new City : ");
					city = scInput.nextLine();

					hotelDetailsBean.setCity(city);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "3":

					System.out.println("\n\n------------------------------------------\nModify Address of hotel '"
							+ hotelDetailsBean.getHotelname()
							+ "'\n------------------------------------------\n\n");
					System.out.print("Enter new Address : ");
					address = scInput.nextLine();

					hotelDetailsBean.setAddress(address);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "4":

					System.out
							.println("\n\n------------------------------------------\nModify Description of hotel '"
									+ hotelDetailsBean.getHotelname()
									+ "'\n------------------------------------------\n\n");
					System.out.print("Enter new Description : ");
					description = scInput.nextLine();

					hotelDetailsBean.setDescription(description);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "5":

					System.out.println(
							"\n\n------------------------------------------\nModify Average Rate Per Night of hotel '"
									+ hotelDetailsBean.getHotelname()
									+ "'\n------------------------------------------\n\n");
					System.out.print("Enter new Average Rate Per Night : ");
					avgRatePerNight = scInput.nextDouble();
					scInput.nextLine();

					hotelDetailsBean.setAvgRatePerNight(avgRatePerNight);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "6":

					System.out.println(
							"\n\n------------------------------------------\nModify Phone Number(1) of hotel '"
									+ hotelDetailsBean.getHotelname()
									+ "'\n------------------------------------------\n\n");

					System.out.print("Enter new Phone Number (1) : ");
					phoneNo1 = scInput.nextLine();

					hotelDetailsBean.setPhoneNo1(phoneNo1);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "7":

					System.out.println(
							"\n\n------------------------------------------\nModify Phone Number(1) of hotel '"
									+ hotelDetailsBean.getHotelname()
									+ "'\n------------------------------------------\n\n");

					System.out.print("Enter new Phone Number (2) : ");
					phoneNo2 = scInput.nextLine();

					hotelDetailsBean.setPhoneNo2(phoneNo2);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "8":

					System.out.println("\n\n------------------------------------------\nModify Rating of hotel '"
							+ hotelDetailsBean.getHotelname()
							+ "'\n------------------------------------------\n\n");

					System.out.print("Enter new Rating : ");
					rating = scInput.nextLine();

					hotelDetailsBean.setRating(rating);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "9":

					System.out.println("\n\n------------------------------------------\nModify Email of hotel '"
							+ hotelDetailsBean.getHotelname()
							+ "'\n------------------------------------------\n\n");

					System.out.print("Enter new Email : ");
					email = scInput.nextLine();

					hotelDetailsBean.setEmail(email);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "10":

					System.out.println("\n\n------------------------------------------\nModify Fax of hotel '"
							+ hotelDetailsBean.getHotelname()
							+ "'\n------------------------------------------\n\n");

					System.out.print("Enter new Fax : ");
					fax = scInput.nextLine();

					hotelDetailsBean.setFax(fax);

					isUpdated = hotelService.modifyHotel(hotelDetailsBean);

					break;

				case "11":

					System.out
							.println("\n\n------------------------------------------\nModify all fields of hotel '"
									+ hotelDetailsBean.getHotelname() + "' with hotel ID '"
									+ hotelDetailsBean.getHotelId()
									+ "'\n------------------------------------------\n\n");

					System.out.print("Enter new Hotel Name : ");
					hotelName = scInput.nextLine();

					System.out.print("Enter new Address : ");
					address = scInput.nextLine();

					System.out.print("Enter new City : ");
					city = scInput.nextLine();

					System.out.print("Enter new Description : ");
					description = scInput.nextLine();

					System.out.print("Enter new Average Rate Per Night : ");
					avgRatePerNight = scInput.nextDouble();
					scInput.nextLine();

					System.out.print("Enter new Phone Number (1) : ");
					phoneNo1 = scInput.nextLine();

					System.out.print("Enter new Phone Number (2) : ");
					phoneNo2 = scInput.nextLine();

					System.out.print("Enter new Rating : ");
					rating = scInput.nextLine();

					System.out.print("Enter new Email : ");
					email = scInput.nextLine();

					System.out.print("Enter new Fax : ");
					fax = scInput.nextLine();

					HotelBean newHotelDetailsBean = new HotelBean(city, hotelName, address,
							description, avgRatePerNight, phoneNo1, phoneNo2, rating, email, fax);

					isUpdated = hotelService.modifyHotel(newHotelDetailsBean);

					break;

				default:

					System.out.println("\n\nPlease enter a valid option !!\n\n");
					break;
				}
			}

			System.out.println("\nUpdated Hotel Details\n");
			System.out.println(
					"Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");
			System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity() + "     "
					+ hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress() + "      "
					+ hotelDetailsBean.getDescription() + "              " + hotelDetailsBean.getAvgRatePerNight()
					+ "             " + hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2()
					+ "      " + hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      "
					+ hotelDetailsBean.getFax() + "\n\n");

		} else {
			System.out.println("\nHotel record with hotel id " + hotelId + " not found!!\n\n");
		}
	} catch (HbmsException e) {
		System.out.println("Hotel not found!!" + e.getMessage());
	}

	return isUpdated;

}

public boolean addRoom(String role) throws HbmsException {
	
	boolean choiceCity = false;
	boolean roomAdded = false;
	boolean choiceHotelId = false;
	IHotelService hotelService = new HotelServiceImpl();
	List<HotelBean> listOfHotels = new ArrayList<HotelBean>();

	System.out.println("\n\n-----------------\nADD ROOM\n-----------------\n\n");
	System.out.println("1. Search hotel by City to add room");
	System.out.println("2. Cancel\n\n");

	System.out.print("Enter the choice : ");
	String choice = scInput.nextLine();

	switch (choice) {
	case "1":

		List<String> cities = viewCities();

		while (!choiceCity) {

			System.out.println("\nSelect the city\n");
			for (String c : cities) {
				System.out.print(c + "          ");
			}

			System.out.print("\nEnter the city : ");
			city = scInput.nextLine();

			listOfHotels = hotelService.viewHotels(city);
			if (listOfHotels.isEmpty()) {

				System.out.println("\nPlease enter the city name properly !!\n");

			} else {
				choiceCity = true;
				System.out.println(
						"\nHotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

				for (HotelBean hotelDetailsBean : listOfHotels) {
					System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity()
							+ "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress()
							+ "      " + hotelDetailsBean.getDescription() + "              "
							+ hotelDetailsBean.getAvgRatePerNight() + "             "
							+ hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      "
							+ hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      "
							+ hotelDetailsBean.getFax());
				}

				while (!choiceHotelId) {

					System.out.print("\nEnter the hotel Id for which room is to be added : ");
					hotelId = scInput.nextLine();
					if (viewHotelRooms(hotelId, city, role)) {

						choiceHotelId = true;

						while (!roomAdded) {
							if (addRoomDetails(hotelId)) {
								roomAdded = true;
								System.out.println("\nRoom added successfully !!\n\nAdded Room Details\n");

								System.out.println(
										"Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");

								if (roomDetailsBean.getRoomType().equals("AC")) {
									System.out.println(roomDetailsBean.getHotelId() + "             "
											+ roomDetailsBean.getRoomId() + "            "
											+ roomDetailsBean.getRoomNo() + "             "
											+ roomDetailsBean.getRoomType() + "               "
											+ roomDetailsBean.getPerNightRate() + "             "
											+ roomDetailsBean.getAvailability());
								} else {
									System.out.println(roomDetailsBean.getHotelId() + "             "
											+ roomDetailsBean.getRoomId() + "            "
											+ roomDetailsBean.getRoomNo() + "             "
											+ roomDetailsBean.getRoomType() + "           "
											+ roomDetailsBean.getPerNightRate() + "             "
											+ roomDetailsBean.getAvailability());
								}

							} else {
								System.err.println("\nPlease enter a valid Hotel Id !!\n");
							}
						}
					} else {
						System.out.println("\nPlease enter a valid Hotel Id !!\n");
					}
				}
			}
		}
		break;

	case "2":

		System.out.println("\nAdding a room to Hotel has been cancelled !!\n\n");
		break;

	default:
		System.out.println("Select a valid option");
		break;

	}

	return roomAdded;


}

public boolean addRoomDetails(String hotelId2) {
	
	
	boolean isRoomInserted = false;

	System.out.println("\n\n-------------\nAdd Room to Hotel ID " + hotelId + "\n-------------\n");
	System.out.print("\nEnter the room id           : ");
	roomId = scInput.nextLine();
	System.out.print("Enter the room no           : ");
	roomNo = scInput.nextLine();
	System.out.print("Enter the room type         : ");
	roomType = scInput.nextLine();
	System.out.print("Enter the per night rate    : ");
	perNightRate = scInput.nextDouble();
	scInput.nextLine();
	System.out.print("Enter the room availability : ");
	availability = scInput.nextLine();
	photo = null;

	roomDetailsBean = new RoomDetailsBean(hotelId, roomId, roomNo, roomType, perNightRate, availability, photo);

	try {
		isRoomInserted = roomService.insertRoom(roomDetailsBean);

	} catch (HbmsException e) {
		System.out.println(e.getMessage());
	}

	return isRoomInserted;
}

public boolean deleteRoom(String role) throws HbmsException {
	
	
	boolean isDeleted = false;
	boolean choiceCity = false;
	boolean roomDeleted = false;
	boolean choiceHotelId = false;
	IHotelService hotelService = new HotelServiceImpl();
	List<HotelBean> listOfHotels = new ArrayList<HotelBean>();
	List<RoomDetailsBean> listOfRooms = new ArrayList<RoomDetailsBean>();

	System.out.println("\n\n-----------------\nDELETE ROOM\n-----------------\n\n");
	System.out.println("1. Search hotel by City to delete room");
	System.out.println("2. Cancel\n\n");

	System.out.print("Enter the choice : ");
	String choice = scInput.nextLine();

	switch (choice) {

	case "1":
		List<String> cities = viewCities();

		while (!choiceCity) {

			System.out.println("\nSelect the city\n");
			for (String c : cities) {
				System.out.print(c + "          ");
			}

			System.out.print("\nEnter the city : ");
			city = scInput.nextLine();

			listOfHotels = hotelService.viewHotels(city);
			if (listOfHotels.isEmpty()) {

				System.out.println("\nPlease enter the city name properly !!\n");

			} else {
				choiceCity = true;
				System.out.println(
						"\nHotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

				for (HotelBean hotelDetailsBean : listOfHotels) {
					System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity()
							+ "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress()
							+ "      " + hotelDetailsBean.getDescription() + "              "
							+ hotelDetailsBean.getAvgRatePerNight() + "             "
							+ hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      "
							+ hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      "
							+ hotelDetailsBean.getFax());
				}

				while (!choiceHotelId) {

					System.out.print("\nEnter the hotel Id for which room is to be deleted : ");
					hotelId = scInput.nextLine();
					if (viewHotelRooms(hotelId, city, role)) {

						choiceHotelId = true;

						listOfRooms = roomService.viewRooms(hotelId);

						System.out.println("\n\nRoom details for Hotel ID : " + hotelId);

						System.out.println(
								"Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");

						for (RoomDetailsBean roomDetail : listOfRooms) {

							if (roomDetail.getRoomType().equals("AC")) {
								System.out.println(roomDetail.getHotelId() + "             "
										+ roomDetail.getRoomId() + "            " + roomDetail.getRoomNo()
										+ "             " + roomDetail.getRoomType() + "               "
										+ roomDetail.getPerNightRate() + "             "
										+ roomDetail.getAvailability());
							} else {
								System.out.println(roomDetail.getHotelId() + "             "
										+ roomDetail.getRoomId() + "            " + roomDetail.getRoomNo()
										+ "             " + roomDetail.getRoomType() + "           "
										+ roomDetail.getPerNightRate() + "             "
										+ roomDetail.getAvailability());
							}
						}
						while (!roomDeleted) {
							if (deleteRoomDetails(hotelId)) {
								roomDeleted = true;
								isDeleted = true;
								System.out.println("\nRoom deleted successfully !!\n\n");

							} else {
								System.err.println("\nPlease enter a valid Room Id !!\n");
							}
						}

					} else {
						System.out.println("\nPlease enter a valid Hotel Id !!\n");
					}
				}
			}
		}
		break;

	case "2":
		System.out.println("\nDeletion Cancelled !!\n");
		break;

	default:
		System.out.println("\nPlease choose a valid option !!\n");
	}
	return isDeleted;
}

public boolean deleteRoomDetails(String hotelId2) {
	boolean isRoomDeleted = false;

	System.out.println("\n\n-------------\nDelete Room from Hotel with hotel Id " + hotelId + "\n-------------\n");
	System.out.print("\nEnter the room id           : ");
	roomId = scInput.nextLine();

	try {
		isRoomDeleted = roomService.deleteRoom(roomId);
	} catch (HbmsException e) {
		System.out.println(e.getMessage());
	}

	return isRoomDeleted;
}

public boolean updateRoom(String role) throws HbmsException {
	
	boolean isUpdated = false;
	boolean choiceCity = false;
	boolean roomUpdated = false;
	boolean choiceHotelId = false;
	IHotelService hotelService = new HotelServiceImpl();
	List<HotelBean> listOfHotels = new ArrayList<HotelBean>();
	List<RoomDetailsBean> listOfRooms = new ArrayList<RoomDetailsBean>();

	System.out.println("\n\n-----------------\nMODIFY ROOM\n-----------------\n\n");
	System.out.println("1. Search hotel by City to modify room");
	System.out.println("2. Cancel\n\n");

	System.out.print("Enter the choice : ");
	String choice = scInput.nextLine();

	switch (choice) {

	case "1":
		List<String> cities = viewCities();

		while (!choiceCity) {

			System.out.println("\nSelect the city\n");
			for (String c : cities) {
				System.out.print(c + "          ");
			}

			System.out.print("\nEnter the city : ");
			city = scInput.nextLine();

			listOfHotels = hotelService.viewHotels(city);
			if (listOfHotels.isEmpty()) {

				System.out.println("\nPlease enter the city name properly !!\n");

			} else {
				choiceCity = true;
				
				
				System.out.println(
						"\nHotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

				for (HotelBean hotelDetailsBean : listOfHotels) {
					System.out.println(hotelDetailsBean.getHotelId() + "           " + hotelDetailsBean.getCity()
							+ "     " + hotelDetailsBean.getHotelname() + "      " + hotelDetailsBean.getAddress()
							+ "      " + hotelDetailsBean.getDescription() + "              "
							+ hotelDetailsBean.getAvgRatePerNight() + "             "
							+ hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2() + "      "
							+ hotelDetailsBean.getRating() + "      " + hotelDetailsBean.getEmail() + "      "
							+ hotelDetailsBean.getFax());
				}

				while (!choiceHotelId) {

					System.out.print("\nEnter the hotel Id for which room is to be updated : ");
					hotelId = scInput.nextLine();
					if (viewHotelRooms(hotelId, city, role)) {

						choiceHotelId = true;

						listOfRooms = roomService.viewRooms(hotelId);

						System.out.println("\n\nRoom details for Hotel ID : " + hotelId);

						System.out.println(
								"Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");

						for (RoomDetailsBean roomDetail : listOfRooms) {

							if (roomDetail.getRoomType().equals("AC")) {
								System.out.println(roomDetail.getHotelId() + "             "
										+ roomDetail.getRoomId() + "            " + roomDetail.getRoomNo()
										+ "             " + roomDetail.getRoomType() + "               "
										+ roomDetail.getPerNightRate() + "             "
										+ roomDetail.getAvailability());
							} else {
								System.out.println(roomDetail.getHotelId() + "             "
										+ roomDetail.getRoomId() + "            " + roomDetail.getRoomNo()
										+ "             " + roomDetail.getRoomType() + "           "
										+ roomDetail.getPerNightRate() + "             "
										+ roomDetail.getAvailability());
							}
						}

						while (!roomUpdated) {
							System.out.print("\nEnter Room Id for which the details need to be modified : ");
							roomId = scInput.nextLine();
							System.out.println("\n");
							if (roomService.isRoomIdValid(roomId, hotelId)) {
								if (updateRoomDetails(roomId)) {
									roomUpdated = true;
									isUpdated = true;
									System.out.println("\nRoom updated successfully !!\n\n");

								} else {
									System.out.println("\nPlease enter a valid Room Id !!\n");
								}
							} else {
								System.out.println("\nPlease enter a valid Room Id !!\n");
							}
						}

					} else {
						System.out.println("\nPlease enter a valid Hotel Id !!\n");
					}
				}
			}
		}
		break;

	case "2":
		System.out.println("\nUpdation Cancelled !!\n");
		break;

	default:
		System.out.println("\nPlease choose a valid option !!\n");
		break;
	}
	return isUpdated;

}

public boolean updateRoomDetails(String roomId2) {
	
	
	boolean isUpdated = false;
	try {
		RoomDetailsBean roomDetail = roomService.getRoomDetail(roomId);

		if (roomDetail != null) {
			while (!isUpdated) {

				System.out.println("\n");
				System.out.println("Details of room Id '" + roomId + "' are as follows\n");
				System.out.println(
						"Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");

				if (roomDetail.getRoomType().equals("AC")) {
					System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId()
							+ "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType()
							+ "               " + roomDetail.getPerNightRate() + "             "
							+ roomDetail.getAvailability());
				} else {
					System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId()
							+ "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType()
							+ "           " + roomDetail.getPerNightRate() + "             "
							+ roomDetail.getAvailability());
				}
				System.out.println("\n\nModify\n");
				System.out.println("1. Set New Room No");
				System.out.println("2. Set New Room Type");
				System.out.println("3. Set New Per Night Rate");
				System.out.println("4. Set New Availability");

				System.out.println("\n5. Modify All Data\n\n");
				System.out.print("Enter : ");
				String update = scInput.nextLine();
				/*
				 * ============================================EDIT FROM
				 * HERE=============================================
				 */
				switch (update) {
				case "1":
					System.out.println("\n\n------------------------------------------\nModify Room No of Room ID '"
							+ roomDetail.getRoomId() + "'\n------------------------------------------\n\n");
					System.out.print("Enter new Room No : ");
					roomNo = scInput.nextLine();

					roomDetail.setRoomNo(roomNo);

					isUpdated = roomService.modifyRoom(roomDetail);

					break;

				case "2":

					System.out
							.println("\n\n------------------------------------------\nModify Room Type of Room ID '"
									+ roomDetail.getRoomId() + "'\n------------------------------------------\n\n");
					System.out.print("Enter new Room Type : ");
					roomType = scInput.nextLine();

					roomDetail.setRoomNo(roomType);

					isUpdated = roomService.modifyRoom(roomDetail);

					break;

				case "3":

					System.out.println(
							"\n\n------------------------------------------\nModify Per Night Rate of Room ID '"
									+ roomDetail.getRoomId() + "'\n------------------------------------------\n\n");
					System.out.print("Enter new Per Night Rate : ");
					perNightRate = scInput.nextDouble();
					scInput.nextLine();

					roomDetail.setPerNightRate(perNightRate);

					isUpdated = roomService.modifyRoom(roomDetail);

					break;

				case "4":

					System.out.println(
							"\n\n------------------------------------------\nModify Availability of Room ID '"
									+ roomDetail.getRoomId() + "'\n------------------------------------------\n\n");
					System.out.print("Enter new Availability : ");
					availability = scInput.nextLine();

					roomDetail.setAvailability(availability);

					isUpdated = roomService.modifyRoom(roomDetail);

					break;

				case "5":

					System.out.println(
							"\n\n------------------------------------------\nModify All Details of Room ID '"
									+ roomDetail.getRoomId() + "'\n------------------------------------------\n\n");

					System.out.print("Enter new Room No : ");
					roomNo = scInput.nextLine();

					roomDetail.setRoomNo(roomNo);

					System.out.print("Enter new Room Type : ");
					roomType = scInput.nextLine();

					roomDetail.setRoomNo(roomType);

					System.out.print("Enter new Per Night Rate : ");
					perNightRate = scInput.nextDouble();
					scInput.nextLine();

					System.out.print("Enter new Availability : ");
					availability = scInput.nextLine();

					roomDetail.setAvailability(availability);

					isUpdated = roomService.modifyRoom(roomDetail);

					break;

				default:

					System.err.println("\n\nPlease enter a valid option !!\n\n");
					break;
				}
			}

			System.out.println("\nUpdated Room Details\n");
			
			System.out.println(
					"Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");
			
			if (roomDetail.getRoomType().equals("AC")) {
				System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId()
						+ "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType()
						+ "               " + roomDetail.getPerNightRate() + "             "
						+ roomDetail.getAvailability());
			} else {
				System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId()
						+ "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType()
						+ "           " + roomDetail.getPerNightRate() + "             "
						+ roomDetail.getAvailability());
			}

		} else {
			System.out.println("\nRoom details with room id " + roomId + " not found!!\n\n");
		}
	} catch (HbmsException e) {
		System.out.println("Room not found!!" + e.getMessage());
	}

	return isUpdated;
}

}		

	


