package com.capgemini.hbms.ui;

	import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.BookingBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserBean;
import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserServiceImpl;




	public class Admin {
		public void main() {
			
			//PropertyConfigurator.configure("resources/log4j.properties");
			Logger logger = Logger.getLogger(Admin.class);
			
			String userId;
			String password;

			String hotelId;

			String role;
			boolean valid = false;

			Scanner scInput = new Scanner(System.in);

			role = "Admin";

			UserBean userDetailsBean = new UserBean();
			IUserService userService = new UserServiceImpl();
			IHotelService hotelService = new HotelServiceImpl();
			IBookingService bookingService = new BookingServiceImpl();
			IRoomService roomService = new RoomServiceImpl();
			HbmsMain hbms = new HbmsMain();

			System.out.println("------------------\nADMIN\n------------------\n\n");

			System.out.println("1.Login");
			System.out.println("2.Exit\n\n");

			String choiceAdmin;

			choiceAdmin = scInput.nextLine();

			switch (choiceAdmin) {

			case "1":
				logger.info("\n\nLogin\n");
				System.out.println("\n\n-----------------\nADMIN LOGIN\n-----------------\n\n");
				System.out.print("Enter the UserID   : ");
				userId = scInput.nextLine();
				System.out.print("Enter the Password : ");
				password = scInput.nextLine();
				userDetailsBean = new UserBean(userId, password, role);
				try {
					valid = userService.LoginCheck(userDetailsBean);
					if (valid) {
						System.out.println("\n\nSuccessfully Logined!!\n\n");

						String choice;
						System.out.println("\n\n-----------------\nADMIN\n-----------------\n\n");
						System.out.println("1.Hotel Management\n2.Room Management\n3.Reports\n\n");
						choice = scInput.nextLine();

						switch (choice) {

						case "1":
							logger.info("\n\nHotel Management\n");
							System.out.println("\n\n-----------------\nHOTEL MANAGEMENT\n-----------------\n\n");
							System.out.println("1.Add Hotel\n2.Delete Hotel\n3.Modify Hotel\n\n");

							String choiceHotelManagement = scInput.nextLine();

							switch (choiceHotelManagement) {
							case "1":
								logger.info("\n\nAdd Hotel\n");
								boolean isInserted = false;

								while (!isInserted) {

									isInserted = hbms.addHotel();

								}
								break;

							case "2":
								logger.info("\n\nDelete Hotel\n");
								boolean isDeleted = false;

								while (!isDeleted) {

									isDeleted = hbms.deleteHotel(role);
								}
								break;

							case "3":
								logger.info("\n\nModify Hotel\n");
								boolean isUpdated = false;

								while (!isUpdated) {

									isUpdated = hbms.updateHotel(role);

								}
								break;

							default:
								System.out.println("\nPlease select a valid option\n");
							}
							break;

						case "2":
							logger.info("\n\nRoom Management\n");
							System.out.println("\n\n-----------------\nROOM MANAGEMENT\n-----------------\n\n");
							System.out.println("1.Add Room\n2.Delete Room\n3.Modify Room\n\n");

							String choiceRoomManagement = scInput.nextLine();

							switch (choiceRoomManagement) {
							case "1":
								logger.info("\n\nAdd Room\n");
								boolean isInserted = false;

								while (!isInserted) {

									isInserted = hbms.addRoom(role);

								}
								break;

							case "2":
								logger.info("\n\nDelete Room\n");
								boolean isDeleted = false;

								while (!isDeleted) {

									isDeleted = hbms.deleteRoom(role);
								}
								break;

							case "3":
								logger.info("\n\nModify Room\n");
								boolean isUpdated = false;

								while (!isUpdated) {

									isUpdated = hbms.updateRoom(role);

								}
								break;

							default:
								System.out.println("\nPlease select a valid option\n");
							}
							break;

						case "3":
							logger.info("\n\nReports\n");
							System.out.println("\n\n-----------------\nREPORTS\n-----------------\n\n");
							System.out.println(
									"1. View List of Hotels\n2. View Bookings of specific hotel\n3. View guest list of specific hotel\n4. View bookings for specified date\n5. Exit\n");

							String choiceReport = scInput.nextLine();

							switch (choiceReport) {
							
							case "1":
								
								logger.info("\n\nView List of Hotels\n");
								
								List<HotelBean> listOfHotels = hotelService.viewHotelsList();
								System.out.println("\n\n-----------------\nHOTEL LIST\n-----------------\n\n");
								System.out.println(
										"\nHotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");

								for (HotelBean hotelDetailsBean : listOfHotels) {
									System.out.println(hotelDetailsBean.getHotelId() + "           "
											+ hotelDetailsBean.getCity() + "     " + hotelDetailsBean.getHotelname()
											+ "      " + hotelDetailsBean.getAddress() + "      "
											+ hotelDetailsBean.getDescription() + "              "
											+ hotelDetailsBean.getAvgRatePerNight() + "             "
											+ hotelDetailsBean.getPhoneNo1() + "      " + hotelDetailsBean.getPhoneNo2()
											+ "      " + hotelDetailsBean.getRating() + "      "
											+ hotelDetailsBean.getEmail() + "      " + hotelDetailsBean.getFax());
								}
								System.out.println("\n\n");
								break;

							case "2":

								logger.info("\n\nView Bookings of specific hotel\n");
								
								boolean found = false;
								boolean once = false;
								while (!found) {
									List<BookingBean> bookingList = bookingService.getAllBookingDetails();

									System.out.print("\nEnter Hotel Id : ");
									hotelId = scInput.nextLine();

									HotelBean hotelDetail = hotelService.viewHotel(hotelId);

									if (hotelDetail != null) {
										for (BookingBean bookingDetail : bookingList) {

											RoomDetailsBean roomDetailsBean = roomService
													.getRoomDetail(bookingDetail.getRoomId());
											HotelBean hotelDetailsBean = hotelService
													.viewHotel(roomDetailsBean.getHotelId());

											if (hotelDetailsBean.getHotelId().equals(hotelId)) {
												found = true;
												if (!once) {
													
													System.out.println("\n\n---------------------------------------------\nBooking details of hotel with hotel id '" + hotelId + "'\n---------------------------------------------\n\n");
													System.out.println(
															"BookingId      Room ID      User ID       Booked From             Booked To             No of Adult      No of Children      Amount");
													once = true;
												}

												System.out.println(bookingDetail.getBookingId() + "                "
														+ bookingDetail.getRoomId() + "             "
														+ bookingDetail.getUserId() + "          "
														+ bookingDetail.getBookedFrom() + "       "
														+ bookingDetail.getBookedTo() + "      "
														+ bookingDetail.getNoOfAdults() + "      "
														+ bookingDetail.getNoOfChildren() + "      "
														+ bookingDetail.getAmount());

											}

										}

										if (!found) {
											System.out.println("\n\nHotel Id mentioned has no bookings !!\n\n");
										}
									} else {
										System.out.println("\n\nPlease enter a correct hotel Id !!\n\n");
									}
								}
								break;

							case "3":
								
								logger.info("\n\nView guest list of specific hotel\n");
								
								boolean founduser = false;
								boolean onetime = false;
								int flag = 1;
								
								List<UserBean> userNoRepeat = new ArrayList<UserBean>();
								
								while (!founduser) {
									List<BookingBean> bookingList = bookingService.getAllBookingDetails();

									System.out.print("\nEnter Hotel Id : ");
									hotelId = scInput.nextLine();

									HotelBean hotelDetail = hotelService.viewHotel(hotelId);

									if (hotelDetail != null) {

										for (BookingBean bookingDetail : bookingList) {

											RoomDetailsBean roomDetailsBean = roomService
													.getRoomDetail(bookingDetail.getRoomId());
											HotelBean hotelDetailsBean = hotelService
													.viewHotel(roomDetailsBean.getHotelId());
											UserBean user = userService.getUserDetails(bookingDetail.getUserId());
											if (hotelDetailsBean.getHotelId().equals(hotelId)) {
												founduser = true;

												if (userNoRepeat.isEmpty()) {
													userNoRepeat.add(user);
												} else{
													for (UserBean userList : userNoRepeat){
														if (userList.getUserId().equalsIgnoreCase(user.getUserId())) {
															flag = 0;
															break;
														}
													}
													if (flag == 1) {
														userNoRepeat.add(user);
													}
													flag = 1;

												}

											}
										}

										if (!founduser) {
											System.out.println("\n\nHotel Id mentioned has no guest lists !!\n\n");
										} else {
											for (UserBean user : userNoRepeat) {
												if (!onetime) {
													System.out.println("\n\n---------------------------------------------\nGuest Lists in hotel with hotel id '" + hotelId + "'\n---------------------------------------------\n\n");
													System.out.println(
															"Username             Mobile No             Phone             Address             Email\n");
													onetime = true;
												}

												System.out.println(user.getUserName() + "                "
														+ user.getMobileNo() + "             " + user.getPhone()
														+ "               " + user.getAddress() + "             " + user.getEmail());
											}
										}
									} else {
										System.out.println("\n\nPlease enter a correct hotel Id !!\n\n");
									}
								}
								
								
								break;

							case "4":
								
								//logger.info("\n\nView bookings for specified date\n");
								
								System.out.print("\nEnter the date in (dd/MM/yyyy) : ");
								String fDate = scInput.nextLine();
								
								DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
								TemporalAccessor ta =  dtf.parse(fDate);
								LocalDate fromDate = LocalDate.from(ta);
								
								List<BookingBean> listOfBooking = bookingService.getBookingDetailsByDate(fromDate);
								
								if(listOfBooking.isEmpty()){
									System.out.println("\n\nNo hotel bookings on '" + fromDate + "'\n\n");
								}else{
									
									boolean showOnce = false;
									for(BookingBean bookingDetail : listOfBooking){
										if (!showOnce) {
											
											System.out.println("\n\n---------------------------------------------\nBooking details of hotel on date '" + fromDate + "'\n---------------------------------------------\n\n");
											System.out.println(
													"BookingId      Room ID      User ID       Booked From             Booked To             No of Adult      No of Children      Amount");
											showOnce = true;
										}

										System.out.println(bookingDetail.getBookingId() + "                "
												+ bookingDetail.getRoomId() + "             "
												+ bookingDetail.getUserId() + "          "
												+ bookingDetail.getBookedFrom() + "       "
												+ bookingDetail.getBookedTo() + "      "
												+ bookingDetail.getNoOfAdults() + "      "
												+ bookingDetail.getNoOfChildren() + "      "
												+ bookingDetail.getAmount());

									}
									
								}
								break;

							case "5":

								System.out.println("\n!Exit.....!!!!!\n");
								break;

							default:
								System.out.println("\nPlease select a valid option\n");
							}

							break;

						default:
							System.out.println("\nPlease select a valid option\n");
							break;
						}
					}
					else{
						System.out.println("\n\nUserId or password does not exist !!\n\n");
					}
				} catch (HbmsException e) {

					System.out.println(e.getMessage());
				}
				break;

			case "2":

				System.out.println("\nExit\n");
				break;
			default:

				System.out.println("\n\nPlease select a valid option\n\n");
				break;

			}
		}
	}

	
	

