package com.capgemini.hbms.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hbms.bean.BookingBean;

import com.capgemini.hbms.bean.HotelBean;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserBean;

import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserServiceImpl;


public class Customer 
{

	public void customerMain(){
	String userId;
	String password;
	String role;
	boolean valid = false;
	
	Scanner scInput = new Scanner(System.in);
	
	UserBean userBean=new UserBean();
	
	IUserService userService = new UserServiceImpl();
	IHotelService hotelService = new HotelServiceImpl();
	IBookingService bookingService = new BookingServiceImpl();
	IRoomService roomService = new RoomServiceImpl();
	HbmsMain hbms = new HbmsMain();
	
	System.out.println("------------------\nCUSTOMER\n------------------\n\n");
	System.out.println("1.Register");
	System.out.println("2.Login\n\n");
	
	String choiceCustomer;
	role = "Customer";
	
	choiceCustomer = scInput.nextLine();
	
	switch(choiceCustomer){
	
		case "1" :
//==============================================CUSTOMER REGISTER===================================================================											
			//logger.info("\n\nRegister\n\n");
					userBean = (UserBean) hbms.Register(role);
					
					try {
						    int res = userService.validateInputs(userBean);
						    if(res==1)
						    {
							int userID = userService.RegisterUser(userBean);
							System.out
								.println("You have successfully registered!! Your user ID is : " + userID + "\nThis user ID will be needed to login");
						    }
						   
					} catch (HbmsException e) {
						//e.printStackTrace();
						System.out.println("Error while registering\n" + e.getMessage());
						
					}
					
					break;
//==============================================EOF CUSTOMER REGISTER===================================================================				
					
		case "2" : 
//==============================================CUSTOMER LOGIN===================================================================
					
			//logger.info("\n\nLogin\n\n");
					System.out.println("\n\n-----------------\nCUSTOMER LOGIN\n-----------------\n\n");
					System.out.print("Enter the UserID   : ");
					userId = scInput.nextLine();
					System.out.print("Enter the Password : ");
					password = scInput.nextLine();
					userBean = new UserBean(userId,password,role);
					try {
						valid = userService.LoginCheck(userBean);
						if(valid){

							System.out.println("\n\nSuccessfully Logined!!\n\n");
							
							String choiceHotels;
							
							
							System.out
									.println("1.Search and Book Hotel\n2.View Status\n\n");
							choiceHotels = scInput.nextLine();
							
							switch(choiceHotels){
							
								case "1" :
									//logger.info("\n\nSearch and Book Hotel\n\n");
											boolean cityfound = false;
											System.out.println("\nCities");
											
											List<String> cities = hbms.viewCities();
											
											
											while(!cityfound){
												
												System.out.println("\n");	
												
												for(String city : cities){
													System.out.print(city + "      ");
												}

												System.out
														.print("\n\nEnter the city name : ");
												String city = scInput.nextLine();
												int noOfHotels = hbms.HotelSearch(city);
												
												if(noOfHotels > 0){
													
													cityfound = true;
													boolean roomfound = false;
													while(!roomfound)
													{
														System.out
																.print("Enter the Hotel ID : ");
														String hotelId = scInput.nextLine();
														
														boolean viewedRooms = hbms.viewHotelRooms(hotelId,city,role);
														
														if(viewedRooms){
															
															roomfound = true;
															boolean checkRoomAvailability = false;
															
															while(!checkRoomAvailability)
															{
																System.out.print("\nEnter the room ID to be booked : ");
																
																String roomID = scInput.nextLine();
																
																if(roomService.isRoomIdValid(roomID,hotelId)){
																	
																	checkRoomAvailability = roomService.checkRoomAvailability(roomID);
																	
																	if(!checkRoomAvailability){
																		System.out
																				.println("\nRoom ID : " + roomID + " doesn't have rooms available");
																	}else{
																		
																		String bookingId = hbms.Book(roomID, userBean.getUserId());
																		BookingBean bookingDetailsBean = bookingService.getBookingDetail(bookingId);
																		UserBean userDetails = userService.getUserDetails(bookingDetailsBean.getUserId());
																		RoomDetailsBean roomDetailsBean = roomService.getRoomDetail(bookingDetailsBean.getRoomId());
																		HotelBean hotelBean = hotelService.viewHotel(roomDetailsBean.getHotelId());
																		
																
										
																		System.out.println("Username    : " + userDetails.getUserName());
																		System.out.println("Booking ID  : " + bookingDetailsBean.getBookingId());
																		System.out.println("Hotel Name  : " + hotelBean.getHotelname());
																		System.out.println("Room Type   : " + roomDetailsBean.getRoomType());
																		System.out.println("Amount      : " + bookingDetailsBean.getAmount());
																		
																		System.out.println("\n\n");
																	}
																
																
																}else{
																	System.out
																          .println("Enter a valid Room ID !!");
																}
																
																
																
																
															}	
														}else{
															System.out
															.println("\nEnter a valid Hotel ID !!\n");
															roomfound = false;
														}
													}
													
												
												}else{
													System.out.print("\nPlease enter the required city name as below mentioned");
													cityfound = false;
												}
											
											}
											
											break;
											
								case "2" :
									//logger.info("\n\nView Status\n\n");
											System.out
													.println("---------------\nStatus\n---------------");
											
											List<BookingBean> bookingList = bookingService.getBookingDetails(userId);
											
											System.out.println("\n\nUsername      Booking ID      Hotel Name      Room ID      Room Type       From             To             No of Adult      No of Children      Amount");
								
											for(BookingBean bookingDetail : bookingList){
												UserBean userDetails = userService.getUserDetails(bookingDetail.getUserId());
												RoomDetailsBean roomDetailsBean = roomService.getRoomDetail(bookingDetail.getRoomId());
												HotelBean hotelDetailsBean = hotelService.viewHotel(roomDetailsBean.getHotelId());
												
												
												System.out.println(userDetails.getUserName() + "          " + 
												
														bookingDetail.getBookingId() + "          " + hotelDetailsBean.getHotelname() + "         " + roomDetailsBean.getRoomId() + "        " + roomDetailsBean.getRoomType() + "        " + bookingDetail.getBookedFrom() + "        " + bookingDetail.getBookedTo() + "       " + bookingDetail.getNoOfAdults() + "       " + bookingDetail.getNoOfChildren()  + "       " + bookingDetail.getAmount());
		
												
											}

											break;

							
							}
							
							
							
						}else{
							System.err.println("UserId or password does not exist!!");
						}
					} catch (HbmsException e) {
						
						System.out.println(e.getMessage());
					}
					
					break;
//==============================================EOF CUSTOMER LOGIN===================================================================											
		default :
					System.out.println("\nInvalid option selected");
					break;
			
	}
}

}
	
	

