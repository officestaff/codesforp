package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.util.DbUtil;

public class HotelDaoImpl implements IHotelDao{

	Logger logger = Logger.getLogger(HotelDaoImpl.class);
	@Override
	public List<HotelBean> viewHotels() throws HbmsException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		
		
		HotelBean hotelDetailsBean;
		List<HotelBean> hotelsList = new ArrayList<HotelBean>();
		
		try(Connection conn = DbUtil.getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						conn.prepareStatement(QueryMapperHotel.SHOW_HOTELS); // Preparing query
						){
			
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			while(rs.next())
			{
				String hotelId=rs.getString(1);
				String city=rs.getString(2);
				String hotelName=rs.getString(3);
				String address=rs.getString(4);
				String description=rs.getString(5);
				double avgRatePerNight=rs.getDouble(6);
				String phoneNo1=rs.getString(7);
				String phoneNo2=rs.getString(8);
				String rating=rs.getString(9);
				String email=rs.getString(10);
				String fax=rs.getString(11);
				
				hotelDetailsBean = new HotelBean(hotelId,city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
				hotelsList.add(hotelDetailsBean);
			}
			logger.info("HotelDetailsDAO : Retrieved all hotel details list !!");
		} catch(SQLException sqlEx){
			logger.info("HotelDetailsDAO : Couldn't retrieve all hotel details list\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); //Throws error
		}
		return hotelsList;
	}

	@Override
	public HotelBean viewHotel(String hotelId) throws HbmsException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger logger = Logger.getRootLogger();
		
		HotelBean hotelDetailsBean = null;
		
		try(Connection conn = DbUtil.getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						conn.prepareStatement(QueryMapperHotel.SHOW_HOTELDETAILS); // Preparing query
						){
			
			preparedStatement.setString(1, hotelId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			while(rs.next())
			{
				String hotelID=rs.getString(1);
				String city=rs.getString(2);
				String hotelName=rs.getString(3);
				String address=rs.getString(4);
				String description=rs.getString(5);
				double avgPerNightRate=rs.getDouble(6);
				String phoneNo1=rs.getString(7);
				String phoneNo2=rs.getString(8);
				String rating=rs.getString(9);
				String email=rs.getString(10);
				String fax=rs.getString(11);
				
				hotelDetailsBean = new HotelBean(hotelID,city,hotelName,address,description,avgPerNightRate,phoneNo1,phoneNo2,rating,email,fax);
			}
			logger.info("HotelDetailsDAO : Retrieved hotel detail !!");
		} catch(SQLException sqlEx){
			logger.info("HotelDetailsDAO : Couldn't retrieve hotel detail\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); //Throws error
		}
		return hotelDetailsBean;
	}

	@Override
	public int insertHotel(HotelBean hotelDetailsBean)
			throws HbmsException {

		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger logger = Logger.getRootLogger();
		
		int hotelId = 0;
		int records = 0;
		
		try(Connection conn = DbUtil.getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						conn.prepareStatement(QueryMapperHotel.INSERT_HOTEL); // Preparing query
						){
			
			//Giving values to query  statement
			preparedStatement.setString(1, hotelDetailsBean.getCity());
			preparedStatement.setString(2, hotelDetailsBean.getHotelname());
			preparedStatement.setString(3, hotelDetailsBean.getAddress());
			preparedStatement.setString(4, hotelDetailsBean.getDescription());
			preparedStatement.setDouble(5, hotelDetailsBean.getAvgRatePerNight());
			preparedStatement.setString(6, hotelDetailsBean.getPhoneNo1());
			preparedStatement.setString(7, hotelDetailsBean.getPhoneNo2());
			preparedStatement.setString(8, hotelDetailsBean.getRating());
			preparedStatement.setString(9, hotelDetailsBean.getEmail());
			preparedStatement.setString(10, hotelDetailsBean.getFax());
			
			records = preparedStatement.executeUpdate(); //Executing the query
			
			if(records>0){	 //Checking for the record retrieval
				PreparedStatement prepareHotelID = 
						conn.prepareStatement(QueryMapperHotel.SHOW_HOTEL_ID); //Preparing query
				
				ResultSet hotelIDrecord = prepareHotelID.executeQuery(); //Execute query
				
				if(hotelIDrecord.next()){
					hotelId = hotelIDrecord.getInt(1);
					logger.info("HotelDetailsDAO : Inserted Hotel successfully !!");
				}
			}

		} catch(SQLException sqlEx){
			logger.info("HotelDetailsDAO : Couldn't insert hotel detail\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); //Throws error
		}
		
	return hotelId;
	}



	@Override
	public boolean deleteHotel(String hotelId) throws HbmsException {

		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger logger = Logger.getRootLogger();
		
		int result = 0;
		boolean isDeleted = false;
		try(Connection conn = DbUtil.getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						conn.prepareStatement(QueryMapperHotel.DELETE_HOTEL); // Preparing query
						){
			
			preparedStatement.setString(1, hotelId);
			result = preparedStatement.executeUpdate(); //Executing the query
			if(result>0){
				isDeleted = true;
				logger.info("HotelDetailsDAO : Deleted hotel detail !!");
			}
		} catch(SQLException sqlEx){
			logger.info("HotelDetailsDAO : Couldn't delete hotel detail\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); //Throws error
		}
		return isDeleted;
	}

	@Override
	public boolean modifyHotel(HotelBean hotelDetailsBean) throws HbmsException {

		int records = 0;
		boolean isUpdated = false;
		try(Connection conn = DbUtil.getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						conn.prepareStatement(QueryMapperHotel.MODIFY_HOTEL); // Preparing query
						){
			
			//Giving values to query  statement
			preparedStatement.setString(1, hotelDetailsBean.getCity());
			preparedStatement.setString(2, hotelDetailsBean.getHotelname());
			preparedStatement.setString(3, hotelDetailsBean.getAddress());
			preparedStatement.setString(4, hotelDetailsBean.getDescription());
			preparedStatement.setDouble(5, hotelDetailsBean.getAvgRatePerNight());
			preparedStatement.setString(6, hotelDetailsBean.getPhoneNo1());
			preparedStatement.setString(7, hotelDetailsBean.getPhoneNo2());
			preparedStatement.setString(8, hotelDetailsBean.getRating());
			preparedStatement.setString(9, hotelDetailsBean.getEmail());
			preparedStatement.setString(10, hotelDetailsBean.getFax());
			preparedStatement.setString(11, hotelDetailsBean.getHotelId());			
			
			records = preparedStatement.executeUpdate(); //Executing the query
			
			if(records>0){	 //Checking for the record retrieval
				isUpdated = true;
				logger.info("HotelDetailsDAO : Modified hotel detail !!");
			}

		} catch(SQLException sqlEx){
			logger.info("HotelDetailsDAO : Couldn't modify hotel detail\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); //Throws error
		}
		
	return isUpdated;
	}


}
