package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HbmsException;

public interface IRoomDao {

	List<RoomDetailsBean> getRoomHotelID() throws HbmsException;

	boolean checkRoomAvailability(String roomID)throws HbmsException;

	List<RoomDetailsBean> viewRooms(String hotelId) throws HbmsException;

	String getRoomRate(String roomID)throws HbmsException;

	List<String> getAllRoomIds() throws HbmsException;

	RoomDetailsBean getRoomDetail(String roomId)throws HbmsException;

	boolean modifyRoom(RoomDetailsBean roomDetail)throws HbmsException;

	boolean insertRoom(RoomDetailsBean roomDetailsBean) throws HbmsException;

	boolean deleteRoom(String roomId) throws HbmsException;

}
