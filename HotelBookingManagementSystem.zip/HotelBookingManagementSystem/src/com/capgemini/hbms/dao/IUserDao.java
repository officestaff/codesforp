package com.capgemini.hbms.dao;


import java.util.List;

import com.capgemini.hbms.bean.UserBean;
import com.capgemini.hbms.exception.HbmsException;

public interface IUserDao {

	int RegisterUser(UserBean userDetails) throws HbmsException ;

	public List<UserBean> getUserCredentials()throws HbmsException;

	public UserBean getUserDetails(String userId) throws HbmsException;

}
