package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import org.apache.log4j.Logger;

import com.capgemini.hbms.bean.UserBean;


import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.util.DbUtil;



public class UserDaoImpl implements IUserDao{
	Logger logger = Logger.getLogger(UserDaoImpl.class);
	UserBean userDetailsBean = new UserBean();
	
	
	@Override
	public int RegisterUser(UserBean userDetails) throws HbmsException {
					
			int userId = 0;
			int records = 0;
			
		//	PropertyConfigurator.configure("resources/log4j.properties");
		//Logger logger = Logger.getRootLogger();
			
			try(Connection conn = DbUtil.getConnection(); //DataBase Connection
					PreparedStatement preparedStatement=
							conn.prepareStatement(QueryMapperUser.REGISTER_CUSTOMER); // Preparing query
							){
				
				//Giving values to query  statement
				preparedStatement.setString(1, userDetails.getPassword());
				preparedStatement.setString(2, userDetails.getRole());
				preparedStatement.setString(3, userDetails.getUserName());
				preparedStatement.setString(4, userDetails.getMobileNo());
				preparedStatement.setString(5, userDetails.getPhone());
				preparedStatement.setString(6, userDetails.getAddress());
				preparedStatement.setString(7, userDetails.getEmail());

				
				records = preparedStatement.executeUpdate(); //Executing the query
				
				if(records>0){	 //Checking for the record retrieval
					PreparedStatement preparePatientID = 
							conn.prepareStatement(QueryMapperUser.SHOW_USERID); //Preparing query
					
					ResultSet userIDrecord = preparePatientID.executeQuery(); //Execute query
					
					if(userIDrecord.next()){
						userId = userIDrecord.getInt(1); //Patient ID Retrieved
						logger.info("UserDetailsDAO : User registered !!");
					}
				}

			} catch(SQLException sqlEx){
				logger.info("UserDetailsDAO : User cannot be registered\n" + sqlEx.getMessage());
				throw new HbmsException(sqlEx.getMessage()); //Throws error	
			}
			
		return userId;
			
		}
	

	@Override
	public List<UserBean> getUserCredentials() throws HbmsException {
	
		
		UserBean userBean=new UserBean();
		List<UserBean> userCredentialsList = new ArrayList<UserBean>();
		
		try(Connection conn = DbUtil.getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						conn.prepareStatement(QueryMapperUser.GET_USER_CREDENTIALS); // Preparing query
						){
			
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				String userId=rs.getString(1);
				String pass=rs.getString(2);
				String role=rs.getString(3);
				
				userBean = new UserBean(userId,pass,role);
				userCredentialsList.add(userBean);
			}
			logger.info("UserDetailsDAO : User credentials list retrieved !!");
		} catch(SQLException sqlEx){
			logger.info("UserDetailsDAO : User credentials list could not be retrieved\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); //Throws error
		}
		System.out.println(userCredentialsList);
		return userCredentialsList;
		
	}

	@Override
	public UserBean getUserDetails(String userId) throws HbmsException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger logger = Logger.getRootLogger();
		
		
		UserBean userDetails = new UserBean();
		
		try(Connection conn = DbUtil.getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						conn.prepareStatement(QueryMapperUser.GET_USER_DETAILS); // Preparing query
						){
			
			preparedStatement.setString(1, userId);
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				String userID = rs.getString(1);
				String password = rs.getString(2);
				String role = rs.getString(3);
				String userName = rs.getString(4);
				String mobileNo = rs.getString(5);
				String phoneNo = rs.getString(6);
				String address = rs.getString(7);
				String email = rs.getString(8);
				
				userDetails = new UserBean(userID,password,role,userName,mobileNo,phoneNo,address,email);
			}
			logger.info("UserDetailsDAO : User Detail Retrieved !!");
		} catch(SQLException sqlEx){
			logger.info("UserDetailsDAO : User Detail couldn't be Retrieved\n" + sqlEx.getMessage());
			throw new HbmsException(sqlEx.getMessage()); //Throws error
		}
		return userDetails;
	}

	
	}


