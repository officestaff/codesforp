package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.exception.HbmsException;

public interface IHotelDao {

	List<HotelBean> viewHotels() throws HbmsException;

	HotelBean viewHotel(String hotelId)throws HbmsException;

	int insertHotel(HotelBean hotelDetailsBean) throws HbmsException;

	boolean deleteHotel(String hotelId)throws HbmsException;

	boolean modifyHotel(HotelBean hotelDetailsBean) throws HbmsException;

}
