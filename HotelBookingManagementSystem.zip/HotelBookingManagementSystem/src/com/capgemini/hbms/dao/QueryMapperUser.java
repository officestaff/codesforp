package com.capgemini.hbms.dao;

public interface QueryMapperUser {

	public static final String REGISTER_CUSTOMER = "INSERT INTO Users VALUES(userId_sequence.nextval,?,?,?,?,?,?,?)";
	public static final String SHOW_USERID = "SELECT userId_sequence.CURRVAL FROM DUAL";
	
	public static final String GET_USER_CREDENTIALS = "SELECT user_id,password,role FROM Users";
	
	public static final String GET_USER_DETAILS = "SELECT * FROM Users WHERE user_id = ?";


	
	
}
