package com.capgemini.hbms.exception;

public class HbmsException extends Exception {

	
	public HbmsException()
	{
		super();
	}
	
	
	public HbmsException(String message)
	{
		super(message);
	}
}
