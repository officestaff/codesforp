package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.hbms.bean.BookingBean;
import com.capgemini.hbms.exception.HbmsException;

public interface IBookingService {

	String bookHotelRoom(BookingBean bookingBean) throws HbmsException;

	List<BookingBean> getBookingDetails(String userId)throws HbmsException;

	List<BookingBean> getAllBookingDetails() throws HbmsException;

	List<BookingBean> getBookingDetailsByDate(LocalDate fromDate) throws HbmsException;

	BookingBean getBookingDetail(String bookingId) throws HbmsException;



}
