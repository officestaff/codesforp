package com.capgemini.hbms.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;






import com.capgemini.hbms.bean.UserBean;
import com.capgemini.hbms.dao.BookingDaoImpl;
import com.capgemini.hbms.dao.IBookingDao;
import com.capgemini.hbms.dao.IUserDao;
import com.capgemini.hbms.dao.QueryMapperUser;
import com.capgemini.hbms.dao.UserDaoImpl;
import com.capgemini.hbms.exception.HbmsException;
import com.capgemini.hbms.util.DbUtil;

public class UserServiceImpl implements IUserService{

	//IUserDao userDao;

	IUserDao userDao = new UserDaoImpl();
	IBookingDao bookDao=new BookingDaoImpl();
	@Override
	public int RegisterUser(UserBean bean) throws HbmsException {
	
		return userDao.RegisterUser(bean);
	}
	@Override
	public boolean LoginCheck(UserBean userBean) throws HbmsException {
		

		boolean validUser = false;
		List<UserBean> userCredentialsLists = userDao.getUserCredentials();
		
		for(UserBean userCredentialsList : userCredentialsLists){
			if(userCredentialsList.getUserId().equals(userBean.getUserId())&&userCredentialsList.getPassword().equals(userBean.getPassword())&&userCredentialsList.getRole().equals(userBean.getRole())){
				validUser = true;
				break;
			}
		}
		System.out.println(validUser);
		return validUser;
		
			}
	
	public UserBean getUserDetails(String userId) throws HbmsException {
		
		return userDao.getUserDetails(userId);
	}
	@Override
	public int validateInputs(UserBean userBean) throws HbmsException {

		if(!userBean.getUserName().matches("[A-Z][A-Za-z]{1,19}"))
		{
			throw new HbmsException("Name should start with a capital letter and shold be minimum 20 characters ");
		}
		
		
		//checks whether entered phone number is 10 digit number
		if(!userBean.getMobileNo().matches("\\d{10}"))
		{
			throw new HbmsException("please enter valid Phone number");
		}
		
		if(!userBean.getPhone().matches("\\d{8}"))
		{
			throw new HbmsException("please enter valid Phone number");
		}
		return 1;
		
	}
		
	

	}
	
	
	
	
	

