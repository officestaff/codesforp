package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.dao.IRoomDao;
import com.capgemini.hbms.dao.RoomDaoImpl;
import com.capgemini.hbms.exception.HbmsException;

public class RoomServiceImpl implements IRoomService{

	IRoomDao roomDetailsDao = new RoomDaoImpl();
	
	@Override
	public boolean isRoomIdValid(String roomID, String hotelId)
			throws HbmsException {

		boolean roomIdFound = false;
		List<RoomDetailsBean> roomIdList;
		try {
			roomIdList = roomDetailsDao.getRoomHotelID();

			for(RoomDetailsBean roomHotelID : roomIdList){
				if(roomHotelID.getRoomId().equals(roomID)&&roomHotelID.getHotelId().equals(hotelId)){
					roomIdFound = true;
					break;
				}
			}

			
		} catch (HbmsException e) {
			System.out.println("Rooms couldnt be found");
			e.printStackTrace();
		}
			
		return roomIdFound;
	
	
	}

	@Override
	public boolean checkRoomAvailability(String roomID) throws HbmsException {
		return roomDetailsDao.checkRoomAvailability(roomID);
	}

	@Override
	public List<RoomDetailsBean> viewRooms(String hotelId) throws HbmsException {
		return roomDetailsDao.viewRooms(hotelId);  
	}

	@Override
	public String getRoomRate(String roomID) throws HbmsException {
		return roomDetailsDao.getRoomRate(roomID);	}

	

	@Override
	public RoomDetailsBean getRoomDetail(String roomId) throws HbmsException {
		return roomDetailsDao.getRoomDetail(roomId);
	}

	@Override
	public boolean modifyRoom(RoomDetailsBean roomDetail) throws HbmsException {
	
		return roomDetailsDao.modifyRoom(roomDetail);
	}

	@Override
	public boolean insertRoom(RoomDetailsBean roomDetailsBean)
			throws HbmsException {
		return roomDetailsDao.insertRoom(roomDetailsBean);
	}

	@Override
	public boolean deleteRoom(String roomId) throws HbmsException {
		return roomDetailsDao.deleteRoom(roomId);
	}

	

}
